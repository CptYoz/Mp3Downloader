package com.example.mp3downloader;

import java.util.ArrayList;

public interface AddList {
    public void addList(ArrayList<String> addedN,ArrayList<String> addedP);
}
