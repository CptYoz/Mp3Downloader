package com.example.mp3downloader;

import java.util.ArrayList;

public interface passAdded {
    public void passList(ArrayList<String> a,ArrayList<String> b);
}
