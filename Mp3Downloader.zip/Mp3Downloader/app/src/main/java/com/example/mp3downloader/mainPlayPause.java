package com.example.mp3downloader;

public interface mainPlayPause{
    public void nextSongg();
    public void prevSongg();
}
