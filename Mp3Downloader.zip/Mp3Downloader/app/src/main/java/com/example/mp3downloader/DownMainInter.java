package com.example.mp3downloader;

import java.util.ArrayList;

public interface DownMainInter {
    public void songStuu(int pos);
    public void listUpdatee(ArrayList<String> names, ArrayList<String> paths);
    void notPlaying(String s);


}
