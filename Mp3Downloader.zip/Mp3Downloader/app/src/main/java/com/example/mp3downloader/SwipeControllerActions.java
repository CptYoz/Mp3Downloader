package com.example.mp3downloader;

interface SwipeControllerActions {

    public void onLeftClicked(int position);

    public void onRightClicked(int position);
}
