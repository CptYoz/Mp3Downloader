package com.example.mp3downloader;

public interface RemoveFragment {
    public void RemoveF();
}
